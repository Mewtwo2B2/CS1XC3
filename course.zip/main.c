/**
 * @mainpage Course demonstration
 * The main will output:
 * 
 * - the student's name, 
 * - student's id, 
 * - student's grade, 
 * - student's average grade, 
 * - the top student information, 
 * - total number of student who pass, 
 * - and the passing student's information.
 * 
 * @file main.c
 * @author Bozhi Zhang
 * @brief This file is the final result.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief A space is opened in memory, create a pointer named MATH101 and point that memory. The name and code are given as well.
 * @brief Create 20 students by for loop.
 * @brief After that comes the various printouts.
 * @brief The last for loop is used to iterate through all the students that passed and print them out.
 * @return int 0
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}