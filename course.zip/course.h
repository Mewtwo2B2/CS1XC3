/**
 * @file course.h
 * @author Bozhi Zhang
 * @brief This is a class that represents a course.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief This class defines a new type called course, which requires four inputs: name, code, a type of Student pointer, and a total number of students.
 * 
 */
typedef struct _course 
{
  /// char type of course name.
  char name[100];
  /// char type of course code.
  char code[10];
  /// student type of student. 
  Student *students;
  /// int type of total number students.
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


