var student_8h =
[
    [ "_student", "struct__student.html", "struct__student" ],
    [ "Student", "student_8h.html#ac91ec92866bb82e1ee36c75280929c43", null ],
    [ "add_grade", "student_8h.html#a1ee4302d01d8908db57e238f5f9dd9f5", null ],
    [ "average", "student_8h.html#a3efb000301e4e0c8e68930bc93e0958e", null ],
    [ "generate_random_student", "student_8h.html#ad0f523c2c17c9b40389cd8031052fc85", null ],
    [ "print_student", "student_8h.html#a4d964bf73eb1b291728dbf7380a9e6ab", null ]
];