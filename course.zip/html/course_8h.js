var course_8h =
[
    [ "_course", "struct__course.html", "struct__course" ],
    [ "Course", "course_8h.html#a2540079ef5f89c5f4aea7a0255f11475", null ],
    [ "enroll_student", "course_8h.html#af3abbc650ef56ffff427a62dad63fc77", null ],
    [ "passing", "course_8h.html#ab1ba9629dc52188231bb689d3a855813", null ],
    [ "print_course", "course_8h.html#a99bf8b3f3c2d5dc7cf798ed445eaaa77", null ],
    [ "top_student", "course_8h.html#ac1d82150824c7ecd43bab36fb83cd779", null ]
];