/**
 * @file student.h
 * @author Bozhi Zhang
 * @brief This is a class that represents a stuent.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief This class defines a new type called student, which requires five inputs: first_name, last_name, id, grades pointer, and num_grades.
 * 
 */
typedef struct _student 
{ 
  /// char type of student first name.
  char first_name[50];
  /// char type of student last name.
  char last_name[50];
  /// char type of student id.
  char id[11];
  /// double type of grades pointer.
  double *grades; 
  /// int type of student number of grades.
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
